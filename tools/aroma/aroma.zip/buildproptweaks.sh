#!/system/bin/sh
#Selection 1 is for LCD Density
selection1=$(grep "selected.1" /tmp/aroma/buildpropmods.prop | sed 's/selected.1*.//')
if [ -e /system/densitybackup.prop ]
then
. /system/densitybackup.prop
else
chmod 755 /tmp/aroma/currentdensity.prop
. /tmp/aroma/currentdensity.prop
cat /tmp/aroma/currentdensity.prop >> /system/build.prop
cp /tmp/aroma/currentdensity.prop /system/densitybackup.prop
fi

if [ "$selection1" == "1" ]; then
customdensity=$stockdensity
fi
if [ "$selection1" == "2" ]; then
customdensity=180
fi
if [ "$selection1" == "3" ]; then
customdensity=200
fi
if [ "$selection1" == "4" ]; then
customdensity=220
fi
if [ "$selection1" == "5" ]; then
customdensity=240
fi
if [ "$selection1" == "6" ]; then
customdensity=260
fi
if [ "$selection1" == "7" ]; then
customdensity=280
fi
if [ "$selection1" == "8" ]; then
customdensity=300
fi
if [ "$selection1" == "9" ]; then
customdensity=320
fi
if [ "$selection1" == "10" ]; then
customdensity=340
fi
if [ "$selection1" == "11" ]; then
customdensity=360
fi
if [ "$selection1" == "12" ]; then
customdensity=380
fi
if [ "$selection1" == "13" ]; then
customdensity=400
fi
if [ "$selection1" == "14" ]; then
customdensity=420
fi
if [ "$selection1" == "15" ]; then
customdensity=440
fi
if [ "$selection1" == "16" ]; then
customdensity=460
fi
if [ "$selection1" == "17" ]; then
customdensity=480
fi
echo 'customdensity='$customdensity > /sdcard/customdensity
echo $customdensity" is stock density from Aroma" >> /tmp/recovery.log
sed -i -e '/customdensity=/d' /system/build.prop
sed -i -e '/ro.sf.lcd_density=/d' /system/build.prop
echo 'ro.sf.lcd_density='$customdensity >> /system/build.prop
echo 'customdensity='$customdensity >> /system/build.prop

selection2=$(grep "selected.2" /tmp/aroma/buildpropmods.prop | sed 's/selected.2*.//')
if [ "$selection2" == "1" ]; then
sed -i -e '/debug.sf.nobootanimation=1/d' /system/build.prop
echo "Enabled boot animations from Aroma" >> /tmp/recovery.log
fi
if [ "$selection2" == "2" ]; then
echo "debug.sf.nobootanimation=1" >> /system/build.prop
echo "Disabled boot animations from Aroma" >> /tmp/recovery.log
fi
