#!/sbin/sh
if [ -e "/sdcard/bootani/bootanimation.zip" ]; then
rm /system/media/bootanimation.zip
cp /sdcard/bootani/bootanimation.zip /system/media/bootanimation.zip
fi
