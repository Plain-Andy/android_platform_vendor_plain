#!/system/bin/sh
cp /system/build.prop /tmp/aroma-data/build.prop
