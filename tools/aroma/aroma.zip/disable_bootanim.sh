#!/sbin/sh
echo "debug.sf.nobootanimation=1" >> /system/build.prop
