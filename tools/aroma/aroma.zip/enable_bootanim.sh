#!/sbin/sh
sed -i -e '/debug.sf.nobootanimation=1/d' /system/build.prop
