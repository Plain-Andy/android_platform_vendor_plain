#!/sbin/sh
echo persist.sys.usb.config=mass_storage,adb >> /system/build.prop
