#!/sbin/sh
echo persist.sys.usb.config=mtp,adb >> /system/build.prop
